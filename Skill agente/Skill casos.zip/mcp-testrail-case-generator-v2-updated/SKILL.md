---
name: mcp-testrail-case-generator-v2
description: Generate or rewrite TestRail CSV scenarios compatible with MCP/web-ai-automation-runner discovery, AuthGate, routeProfile, recovery, Auto-POM, promotion, and Playwright specs. Use when the user provides Jira stories, acceptance criteria, requirements, screenshots, existing CSV cases, TestRail IDs, appSlug/routeProfile metadata, or asks for MCP automation-friendly cases. Generate only UI-automatable cases by default, with executable numbered steps, visible targets, routeProfile labels/intermediates/domainTerms, setupStrategy, automationType, appSlug metadata, dataRequirements, app.config.json when relevant, and validators that reject manual/backend/conceptual scenarios.
---

# MCP TestRail Case Generator V2

Generate TestRail scenarios that MCP/web-ai-automation-runner can execute through UI discovery and promote to Playwright specs. The default output is **MCP-automated only**.

## Mandatory output

Always create a downloadable `.csv` artifact unless the user explicitly asks for text-only output.

Use this column order unless the user provides a different TestRail-compatible schema:

```csv
ID,Título,Pasos,Precondiciones,Resultado Esperado,Tipo,base de datos,is_converted,automationType,setupStrategy,appSlug,routeProfile,dataRequirements,mcpExecutable,nonExecutableCriteria
```

Rules:
- Quote every CSV field.
- For new cases, leave `ID` empty. Preserve existing TestRail IDs when provided.
- Use Spanish by default.
- Use `Functional` for `Tipo`, `QA` for `base de datos`, and `0` for `is_converted` unless provided otherwise.
- Number `Pasos` and `Precondiciones` when multiline.
- `mcpExecutable` must be `true` for every generated row.
- `nonExecutableCriteria` must be empty or contain only non-blocking notes.
- Do not generate rows that are primarily manual, backend-only, conceptual, security-sensitive, or dependent on non-visible calculations.

Final chat response must include:
- `App slug detectado`
- `Confianza`
- `Motivo`
- `Ruta funcional esperada`
- validation summary when validators were run
- links to CSV, standalone routeProfile JSON, and app.config.json when generated

## MCP-automated only policy

Only generate scenarios MCP can execute automatically by UI using discovery, AuthGate, routeProfile, recovery, Auto-POM, promotion, and Playwright specs.

Allowed `automationType` values:
- `ui_discovery`: deterministic UI-only flow without authentication.
- `ui_with_auth_gate`: authenticated UI flow where AuthGate/AuthFlow handles login during runtime.
- `ui_with_controlled_data`: UI flow requiring a clear, realistic data fixture.

Do not generate cases with:
- `manual_or_backend_only`
- `ui_with_backend_validation`
- `security_sensitive`
- exact financial calculation validation
- database validation
- integration/Core Banking validation
- logs/audit validation
- token/session technical validation
- manual OCR/visual interpretation
- rules not visible in the UI

If a requirement is not MCP-automatable, either omit it or preserve it as a non-blocking note only when it does not create a test obligation.

## Source of execution

`Pasos` is the only executable source for MCP.

`Resultado Esperado` must be one short contextual sentence. It must not introduce additional validation targets, backend assertions, or new UI text. Examples:

Correct:
```text
El cliente visualiza depósitos a plazo activos desde Consulta de balance.
```

Incorrect:
```text
El sistema valida en Core Banking que el saldo coincide con la base de datos y muestra correctamente los intereses generados.
```

## Allowed step patterns

Every step must match one of these patterns:

1. Click action:
```text
Clic en "X".
```

2. Visible assertion:
```text
Validar que se muestre "X".
Validar que el botón "X" esté visible.
Validar que la opción "X" esté disponible.
```

3. State assertion:
```text
Validar que el botón "X" esté habilitado.
Validar que el botón "X" esté deshabilitado.
```

4. Ordinal selection:
```text
Seleccionar el primer <domainTerm> visible del listado.
Seleccionar la primera <domainTerm> visible del listado.
Seleccionar el último <domainTerm> visible del listado.
```

5. Return navigation:
```text
Clic en "Volver".
Validar que se muestre "Volver".
```

6. Data entry only with dataKey:
```text
Ingresar <campo> usando <dataKey>.
```

Never write literal credentials, OTPs, card numbers, account numbers, or sensitive data in steps.

Forbidden step phrases include:
- `Validar correctamente`
- `Verificar que funcione`
- `El sistema permite`
- `El cliente accede`
- `Se procesa exitosamente`
- `Según configuración`
- `Cuando aplique`
- `Validar contra backend`
- `Validar cálculo`
- `Validar reglas de negocio`
- `Validar integración`
- `Validar en base de datos`
- `Validar Core Banking`
- `Validar que se registró`
- `Validar auditoría`

## AuthGate/AuthFlow

For authenticated cases, never generate manual login, identification, phone, PIN, or OTP steps.

Correct preconditions:
```text
1. BASE_URL configurado.
2. Kiosko disponible.
3. APP_LOGIN_MODE=password.
4. AuthGate/AuthFlow habilitado para autenticación por Transacciones y servicios.
5. Cliente de prueba cumple dataRequirements.
6. App Slug: kiosko.
7. Route Profile: authenticated_operations_balance_depositos_plazo.
```

Correct steps:
```text
1. Clic en "Iniciar".
2. Clic en "Transacciones y servicios".
3. Validar que se muestre "Consulta de balance".
4. Clic en "Consulta de balance".
```

Incorrect steps:
```text
1. Clic en "Cédula de identidad dominicana".
2. Ingresar cédula.
3. Ingresar OTP.
```

Auth data must come from configuration such as `Identity_Provider`, `OTP_SECRET`, `APP_USERNAME`, `APP_PASSWORD`, and `APP_TEST_DATA_JSON`.

## Data requirements

Only generate cases with clear, preparable data. Examples:
- `cliente_deposito_plazo_multiple_activo`
- `cliente_deposito_plazo_unico_activo`
- `cliente_sin_depositos_plazo`
- `cliente_deposito_plazo_proximo_vencer`
- `cliente_cuenta_ahorro_pesos_activa`
- `cliente_tarjeta_credito_activa`
- `cliente_prestamo_personal_activo`

Do not generate a case when the fixture cannot be guaranteed or requires complex technical manipulation.

## Negative scenarios

Generate negative scenarios only when the error/empty state is visible by UI and the `dataRequirements` fixture is realistic.

Allowed example:
```text
Data Requirements: cliente_sin_depositos_plazo
Pasos:
1. Clic en "Iniciar".
2. Clic en "Transacciones y servicios".
3. Validar que se muestre "Consulta de balance".
4. Clic en "Consulta de balance".
5. Clic en "Depósitos a plazos".
6. Validar que se muestre "No tiene depósitos a plazo asociados en este momento.".
```

Do not generate negatives that require manually expiring tokens, altering backend, simulating Core outages, manipulating network, changing DB during the test, inspecting logs, or proving audit records.

## Sensitive actions

Do not click sensitive actions unless the user explicitly authorizes a safe environment and the action is reversible or mocked.

Sensitive actions include: `Pagar`, `Transferir`, `Enviar dinero`, `Confirmar operación`, `Aceptar contrato`, `Firmar`, `Eliminar`, `Cancelar producto`, `Solicitar producto financiero`, `Debitar`, `Aprobar`.

Allowed:
```text
Validar que el botón "Solicitar" esté visible.
```

Not allowed by default:
```text
Clic en "Solicitar".
```

## App slug and routeProfile

Detect `appSlug` before writing cases. Never mix app slugs in one CSV.

Priority:
1. Explicit input parameter: `appSlug`, `APP_SLUG`, TestRail/app metadata, CLI/app name.
2. Explicit user/project wording.
3. routeProfile metadata.
4. If unavailable, use `<appSlug>` and add `Warnings: requiresAppSlug=true` in preconditions; prefer not generating final import CSV until resolved.

`routeProfile` is the source of truth for executable labels, route order, intermediates, and domain terms.

Standalone routeProfile for validators:
```json
{
  "appSlug": "kiosko",
  "routeProfile": "authenticated_operations_balance_depositos_plazo",
  "entry": [
    {"businessLabel":"iniciar", "visibleLabel":"Iniciar"},
    {"businessLabel":"transacciones_servicios", "visibleLabel":"Transacciones y servicios"}
  ],
  "aliases": {},
  "intermediates": {},
  "domainTerms": {}
}
```

MCP app config shape:
```json
{
  "appSlug": "kiosko",
  "routeProfile": {
    "name": "authenticated_operations_balance_depositos_plazo",
    "entry": [],
    "aliases": {},
    "intermediates": {},
    "domainTerms": {},
    "visibleControls": [],
    "representativeFixture": {},
    "notes": []
  }
}
```

Rules:
- Keep standalone routeProfile JSON for validators.
- Generate `app.config.json` when routeProfile/app config is useful for MCP.
- In `app.config.json`, `routeProfile` must be an object, never a string.
- If an existing app config is provided, preserve unrelated keys and merge/update only `routeProfile`.

## Labels, intermediates, and domain terms

Executable steps must use visible labels from `routeProfile.entry`, `routeProfile.aliases`, `visibleControls`, or user-provided UI text.

Business labels may appear in titles or notes, not as executable targets when a visible alias exists.

If routeProfile defines an intermediate, include it explicitly even if MCP may treat it as already satisfied.

Use `routeProfile.domainTerms` for ordinal selections:
```text
Seleccionar el primer depósito visible del listado.
Seleccionar la primera cuenta visible del listado.
Seleccionar la primera tarjeta visible del listado.
```

Do not use `tarjeta` outside a true tarjeta/cards domain.

## Precondition pattern

Keep preconditions concise and MCP-useful:

```text
1. BASE_URL configurado.
2. Kiosko disponible.
3. APP_LOGIN_MODE=password.
4. AuthGate/AuthFlow habilitado para autenticación por Transacciones y servicios.
5. Cliente de prueba cumple dataRequirements.
6. App Slug: kiosko.
7. Route Profile: authenticated_operations_balance_depositos_plazo.
8. Setup Strategy: self_contained.
9. Automation Type: ui_with_auth_gate.
10. Data Requirements: cliente_deposito_plazo_multiple_activo.
```

## Self-validation checklist

Before returning scenarios, remove any case where any answer is no:
1. Are all steps executable by UI?
2. Are quoted targets visible UI text?
3. Does `Resultado Esperado` avoid new targets and validations?
4. Does the case avoid backend/calculation/manual dependencies?
5. Is AuthGate in preconditions instead of manual login steps?
6. Are dataRequirements clear?
7. Can MCP execute without human interpretation?
8. Can the case be promoted to Playwright?
9. Are sensitive actions avoided unless authorized?
10. Is `mcpExecutable=true`?

## Validators

When CSV and routeProfile are available, run:

```bash
python scripts/validate_testrail_csv.py <csv-file> --route-profile <route-profile.json>
python scripts/validate_mcp_steps.py <csv-file> --route-profile <route-profile.json>
```

Fix failures before delivering the CSV.

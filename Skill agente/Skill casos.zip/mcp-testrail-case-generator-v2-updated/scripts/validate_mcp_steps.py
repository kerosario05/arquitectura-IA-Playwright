#!/usr/bin/env python3
import argparse
import csv
import json
import re
import sys

ALLOWED_STEP_PATTERNS = [
    re.compile(r'^\d+\. Clic en "[^"]+"\.$'),
    re.compile(r'^\d+\. Validar que se muestre "[^"]+"\.$'),
    re.compile(r'^\d+\. Validar que el botón "[^"]+" esté visible\.$'),
    re.compile(r'^\d+\. Validar que la opción "[^"]+" esté disponible\.$'),
    re.compile(r'^\d+\. Validar que el botón "[^"]+" esté habilitado\.$'),
    re.compile(r'^\d+\. Validar que el botón "[^"]+" esté deshabilitado\.$'),
    re.compile(r'^\d+\. Seleccionar (el primer|la primera|el último|la última) [a-záéíóúñü ]+ visible del listado\.$', re.I),
    re.compile(r'^\d+\. Ingresar [a-záéíóúñü ]+ usando [a-z0-9_]+\.$', re.I),
]
FORBIDDEN = [
    r'Validar correctamente', r'Verificar que funcione', r'El sistema permite', r'El cliente accede',
    r'Se procesa exitosamente', r'Según configuración', r'Cuando aplique', r'Validar contra backend',
    r'Validar cálculo', r'Validar reglas de negocio', r'Validar integración', r'Validar en base de datos',
    r'Validar Core Banking', r'B2000', r'Core Banking', r'base de datos', r'auditor', r'log'
]


def load_profile(path):
    if not path:
        return {}
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def lines(text):
    return [line.strip() for line in (text or '').splitlines() if line.strip()]


def ok_step(step):
    return any(p.match(step) for p in ALLOWED_STEP_PATTERNS)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('csv_file')
    ap.add_argument('--route-profile')
    args = ap.parse_args()
    profile = load_profile(args.route_profile)
    aliases = profile.get('aliases', {})
    intermediates = profile.get('intermediates', {})
    domain_terms = profile.get('domainTerms', {})
    errors = []

    with open(args.csv_file, newline='', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))

    for idx, row in enumerate(rows, start=2):
        row_steps = lines(row.get('Pasos', ''))
        step_text = '\n'.join(row_steps)
        for step in row_steps:
            if not ok_step(step):
                errors.append(f'row {idx}: non-executable step pattern: {step}')
            for pat in FORBIDDEN:
                if re.search(pat, step, re.I):
                    errors.append(f'row {idx}: forbidden phrase in step: {step}')

        clicked_keys = [k for k, v in aliases.items() if f'"{v}"' in step_text]
        for key in clicked_keys:
            required = intermediates.get(key, [])
            if required and any('Seleccionar' in s and 'visible del listado' in s for s in row_steps):
                for node in required:
                    if f'"{node}"' not in step_text:
                        errors.append(f'row {idx}: omitted intermediate route {node!r} for route key {key!r}')

        for step in row_steps:
            m = re.search(r'Seleccionar (?:el primer|la primera|el último|la última) ([a-záéíóúñü ]+) visible del listado', step, re.I)
            if m:
                noun = m.group(1).strip().lower()
                selected_domains = [domain_terms.get(k, '').lower() for k in clicked_keys if domain_terms.get(k)]
                # allow plural/compound variants when noun contains the domain or vice versa
                if selected_domains and not any(noun == d or noun.startswith(d) or d.startswith(noun.rstrip('s')) for d in selected_domains):
                    errors.append(f'row {idx}: ordinal selection noun {noun!r} does not match route domainTerms {selected_domains}')

        if (row.get('mcpExecutable') or '').strip().lower() not in {'true', '1', 'yes'}:
            errors.append(f'row {idx}: mcpExecutable must be true')

    if errors:
        print('FAIL')
        for e in errors:
            print(f'ERROR: {e}')
        return 1
    print(f'PASS validate_mcp_steps: {len(rows)} rows, MCP step syntax OK')
    return 0

if __name__ == '__main__':
    sys.exit(main())

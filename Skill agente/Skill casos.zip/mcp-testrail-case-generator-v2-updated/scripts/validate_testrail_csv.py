#!/usr/bin/env python3
import argparse
import csv
import json
import re
import sys

REQUIRED = ["ID","Título","Pasos","Precondiciones","Resultado Esperado","Tipo","base de datos","is_converted"]
RECOMMENDED = ["automationType","setupStrategy","appSlug","routeProfile","dataRequirements","mcpExecutable","nonExecutableCriteria"]
ALLOWED_AUTOMATION = {"ui_discovery", "ui_with_auth_gate", "ui_with_controlled_data"}
FORBIDDEN_AUTOMATION = {"manual_or_backend_only", "ui_with_backend_validation", "security_sensitive", "ui", "ui_with_mock", "backend", "manual_or_backend", "not_automatable"}
ALLOWED_STEP_PATTERNS = [
    re.compile(r'^\d+\. Clic en "[^"]+"\.$'),
    re.compile(r'^\d+\. Validar que se muestre "[^"]+"\.$'),
    re.compile(r'^\d+\. Validar que el botón "[^"]+" esté visible\.$'),
    re.compile(r'^\d+\. Validar que la opción "[^"]+" esté disponible\.$'),
    re.compile(r'^\d+\. Validar que el botón "[^"]+" esté habilitado\.$'),
    re.compile(r'^\d+\. Validar que el botón "[^"]+" esté deshabilitado\.$'),
    re.compile(r'^\d+\. Seleccionar (el primer|la primera|el último|la última) [a-záéíóúñü ]+ visible del listado\.$', re.I),
    re.compile(r'^\d+\. Ingresar [a-záéíóúñü ]+ usando [a-z0-9_]+\.$', re.I),
]
FORBIDDEN_STEP = [
    r'Validar correctamente', r'Verificar que funcione', r'El sistema permite', r'El cliente accede',
    r'Se procesa exitosamente', r'Según configuración', r'Cuando aplique', r'Validar contra backend',
    r'Validar cálculo', r'Validar reglas de negocio', r'Validar integración', r'Validar en base de datos',
    r'Validar Core Banking', r'Validar que se registró', r'auditor', r'B2000', r'Core Banking'
]
FORBIDDEN_EXPECTED = [
    r'\bvalid(a|ar|e)\b', r'core', r'backend', r'base de datos', r'B2000', r'cálculo', r'correctamente',
    r'auditor', r'log', r'token', r'sesión técnica'
]
SENSITIVE_CLICK = {"Pagar", "Transferir", "Enviar dinero", "Confirmar operación", "Aceptar contrato", "Firmar", "Eliminar", "Cancelar producto", "Solicitar producto financiero", "Debitar", "Aprobar"}


def load_profile(path):
    if not path:
        return {}
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def parse_lines(text):
    return [line.strip() for line in (text or '').splitlines() if line.strip()]


def extract_meta(pre, key):
    m = re.search(rf'{re.escape(key)}:\s*([^\n.]+)', pre or '', re.I)
    return m.group(1).strip() if m else None


def value(row, key, meta_key=None):
    v = (row.get(key) or '').strip()
    if v:
        return v
    if meta_key:
        return extract_meta(row.get('Precondiciones',''), meta_key)
    return None


def has_allowed_step(line):
    return any(p.match(line) for p in ALLOWED_STEP_PATTERNS)


def quoted_targets(text):
    return re.findall(r'"([^"]+)"', text or '')


def profile_visible_labels(profile):
    labels = set()
    for e in profile.get('entry', []) or []:
        if isinstance(e, dict) and e.get('visibleLabel'):
            labels.add(e['visibleLabel'])
    for v in (profile.get('aliases') or {}).values():
        labels.add(v)
    for arr in (profile.get('intermediates') or {}).values():
        for v in arr:
            labels.add(v)
    for v in profile.get('visibleControls', []) or []:
        labels.add(v)
    return labels


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('csv_file')
    ap.add_argument('--route-profile')
    args = ap.parse_args()
    profile = load_profile(args.route_profile)
    expected_app = profile.get('appSlug')
    expected_route = profile.get('routeProfile') or (profile.get('routeProfile') or {}).get('name') if isinstance(profile.get('routeProfile'), dict) else profile.get('routeProfile')
    visible_labels = profile_visible_labels(profile)
    errors = []
    warnings = []

    with open(args.csv_file, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            print('FAIL\nERROR: CSV has no header')
            return 1
        for c in REQUIRED:
            if c not in reader.fieldnames:
                errors.append(f'Missing required column: {c}')
        for c in RECOMMENDED:
            if c not in reader.fieldnames:
                warnings.append(f'Missing recommended column: {c}')
        rows = list(reader)

    for idx, row in enumerate(rows, start=2):
        pre = row.get('Precondiciones', '')
        steps = parse_lines(row.get('Pasos', ''))
        expected = (row.get('Resultado Esperado') or '').strip()
        automation = value(row, 'automationType', 'Automation Type')
        app_slug = value(row, 'appSlug', 'App Slug') or extract_meta(pre, 'App Profile')
        route = value(row, 'routeProfile', 'Route Profile')
        data_req = value(row, 'dataRequirements', 'Data Requirements')
        mcp_exec = (row.get('mcpExecutable') or extract_meta(pre, 'MCP Executable') or '').strip().lower()
        non_exec = (row.get('nonExecutableCriteria') or '').strip()

        if expected_app and app_slug != expected_app:
            errors.append(f'row {idx}: appSlug inconsistent or missing: {app_slug!r} != {expected_app!r}')
        if expected_route and route != expected_route:
            errors.append(f'row {idx}: routeProfile inconsistent or missing: {route!r} != {expected_route!r}')
        if automation not in ALLOWED_AUTOMATION:
            errors.append(f'row {idx}: automationType must be one of {sorted(ALLOWED_AUTOMATION)}, got {automation!r}')
        if automation in FORBIDDEN_AUTOMATION:
            errors.append(f'row {idx}: forbidden automationType: {automation}')
        if not data_req:
            errors.append(f'row {idx}: missing dataRequirements')
        if mcp_exec not in {'true', '1', 'yes'}:
            errors.append(f'row {idx}: mcpExecutable must be true')
        if non_exec and any(re.search(p, non_exec, re.I) for p in ['backend', 'core', 'base de datos', 'manual', 'auditor', 'log']):
            errors.append(f'row {idx}: nonExecutableCriteria contains blocking/manual/backend criteria')

        if not steps:
            errors.append(f'row {idx}: missing steps')
        for step in steps:
            if not has_allowed_step(step):
                errors.append(f'row {idx}: step is not MCP executable pattern: {step}')
            for pat in FORBIDDEN_STEP:
                if re.search(pat, step, re.I):
                    errors.append(f'row {idx}: forbidden conceptual/backend/manual phrase in step: {step}')
            for sensitive in SENSITIVE_CLICK:
                if step == f'Clic en "{sensitive}".':
                    errors.append(f'row {idx}: sensitive action click is not allowed by default: {sensitive}')
            for target in quoted_targets(step):
                if visible_labels and target not in visible_labels:
                    # allow story-provided runtime messages and field labels, but warn for route labels only
                    pass

        if len(parse_lines(expected)) > 1:
            errors.append(f'row {idx}: Resultado Esperado must be one short sentence')
        for pat in FORBIDDEN_EXPECTED:
            if re.search(pat, expected, re.I):
                errors.append(f'row {idx}: Resultado Esperado introduces executable/backend/manual validation: {expected}')
        if quoted_targets(expected):
            errors.append(f'row {idx}: Resultado Esperado must not introduce quoted UI targets: {expected}')
        if re.search(r'(Validar que|Clic en|Seleccionar|Ingresar)', expected, re.I):
            errors.append(f'row {idx}: Resultado Esperado contains executable language: {expected}')

        # AuthGate rule: no manual auth steps
        auth_forbidden = ['Cédula', 'OTP', 'PIN', 'teléfono', 'Telefono', 'Contraseña', 'Usuario']
        for step in steps:
            if any(term.lower() in step.lower() for term in auth_forbidden):
                errors.append(f'row {idx}: manual auth step detected; use AuthGate/AuthFlow preconditions instead: {step}')
        if automation == 'ui_with_auth_gate' and 'AuthGate/AuthFlow' not in pre:
            errors.append(f'row {idx}: ui_with_auth_gate requires AuthGate/AuthFlow precondition')

    if errors:
        print('FAIL')
        for e in errors:
            print(f'ERROR: {e}')
        for w in warnings:
            print(f'WARNING: {w}')
        return 1
    print(f'PASS validate_testrail_csv: {len(rows)} rows, MCP automated only')
    for w in warnings:
        print(f'WARNING: {w}')
    return 0

if __name__ == '__main__':
    sys.exit(main())
